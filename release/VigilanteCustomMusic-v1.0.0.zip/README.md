# Vigilante Custom Music 1.0.0

Replaces the original v8so soundtrack at runtime with personal audio files. No copyrighted music is included or distributed.

## Install

1. Install BepInEx 5 x64.
2. Copy `VigilanteCustomMusic.dll` to `BepInEx/plugins`.
3. Put personal tracks in `BepInEx/plugins/VigilanteCustomMusic/Music`.
4. Start the game.

Supported extensions: `.mp3`, `.ogg`, `.wav`.

Files play alphabetically by default. Prefix filenames with numbers to choose the order, for example `01 - Track.mp3`. Configuration is created at `BepInEx/config/community.v8so.custommusic.cfg` after the first launch.

Options include enabling/disabling replacement, shuffle, volume multiplier, and whether original music stays muted when the custom folder is empty.

